
NAME='cache'
CFLAGS = []
LDFLAGS = []
LIBS = []

GCC_LIST = ['cache']
