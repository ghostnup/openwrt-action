NAME='zabbix'

CFLAGS = []
LDFLAGS = []
LIBS = []

GCC_LIST = ['plugin']
